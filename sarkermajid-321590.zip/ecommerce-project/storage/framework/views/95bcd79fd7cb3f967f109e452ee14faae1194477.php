<?php $__env->startSection('body'); ?>
    <section class="py-5">
        <div class="container">
            <div class="row">
                <div class="col-md-8 mx-auto">
                    <div class="card bg-dark text-white">
                        <div class="card-header"><h4>All Products Information</h4></div>
                        <div class="card-body text-white">
                            <h3 class="text-success text-center"><?php echo e(Session::get('message')); ?></h3>
                            <h3 class="text-danger text-center"><?php echo e(Session::get('message_delete')); ?></h3>
                            <table class="table table-bordered text-white ">
                                <thead>
                                <tr>
                                    <th>SL No</th>
                                    <th>Title</th>
                                    <th>Description</th>
                                    <th>Category Name</th>
                                    <th>Brand Name</th>
                                    <th>Image</th>
                                    <th>Action</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($product->title); ?></td>
                                        <td><?php echo e($product->description); ?></td>
                                        <td><?php echo e($product->category->name); ?></td>
                                        <td><?php echo e($product->brand->name); ?></td>
                                        <td><img src="<?php echo e(asset($product->image)); ?>" alt="" height="50" width="70"></td>
                                        <td>
                                            <a href="<?php echo e(route('product.edit', $product->id)); ?>" class="btn btn-primary btn-sm">Edit</a>
                                            <form action="<?php echo e(route('product.destroy', $product->id)); ?>" method="post">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('delete'); ?>
                                                <button onclick="return confirm('Are you sure to delete this ?')" class="btn btn-danger btn-sm d-inline-block">Delete</button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-sarkermajid\ecommerce-project\resources\views/product/manage.blade.php ENDPATH**/ ?>