<?php $__env->startSection('body'); ?>
    <section class="py-5">
        <div class="container">
            <div class="row">
                <div class="col-md-8 mx-auto">
                    <div class="card bg-dark text-white">
                        <div class="card-header"><h4>Product Information</h4></div>
                        <div class="card-body text-white">
                            <table class="table table-bordered text-white ">
                                <tr>
                                    <th>Product Id</th>
                                    <td><?php echo e($product->id); ?></td>
                                </tr>
                                <tr>
                                    <th>Product Title</th>
                                    <td><?php echo e($product->title); ?></td>
                                </tr>
                                <tr>
                                    <th>Category Name</th>
                                    <td><?php echo e($product->category->name); ?></td>
                                </tr>
                                <tr>
                                    <th>Brand Name</th>
                                    <td><?php echo e($product->brand->name); ?></td>
                                </tr>
                                <tr>
                                    <th>Product Description</th>
                                    <td><?php echo e($product->description); ?></td>
                                </tr>
                                <tr>
                                    <th>Product Code</th>
                                    <td><?php echo e($product->code); ?></td>
                                </tr>
                                <tr>
                                    <th>Product Image</th>
                                    <td><img src="<?php echo e(asset($product->image)); ?>" alt="" height="50" width="70"></td>
                                </tr>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH I:\Laravel Project BITM\ecommerce-project\resources\views/product/view.blade.php ENDPATH**/ ?>