<?php $__env->startSection('body'); ?>

    <section class="py-5">
        <div class="container">
            <div class="row  py-5 bg-dark text-white">
                <div class="col-md-6">
                    <img src="<?php echo e(asset($product->image)); ?>" alt="" height="500" width="500">
                </div>
                <div class="col-md-6">
                    <h2><?php echo e($product->title); ?></h2>
                    <p class="fs-3"><?php echo e($product->description); ?></p>
                    <p class="fs-3">Code : <?php echo e($product->code); ?></p>
                    <p class="fs-5">Category Name: <?php echo e($product->category->name); ?></p>
                    <p class="fs-5">Brand Name : <?php echo e($product->brand->name); ?></p>
                    <a href="" class="btn btn-success d-block">Add to Cart</a>
                </div>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH I:\Laravel Project BITM\ecommerce-project\resources\views/product/details.blade.php ENDPATH**/ ?>