<?php $__env->startSection('body'); ?>

    <section class="py-5">
        <div class="container">
            <div class="row mb-3">
                <p class="display-5 fw-bold text-center text-decoration-underline pb-3" style="font-family: cursive">Products by Category</p>
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-4 mb-3">
                        <div class="card card-body bg-dark text-white h-100">
                            <img src="<?php echo e(asset($product->image)); ?>" alt="" height="200">
                            <h3 class="pt-3"><?php echo e($product->title); ?></h3>
                            <span class="pb-3">Category : <?php echo e($product->category->name); ?> </span>
                            <span class="pb-3">Brand : <?php echo e($product->brand->name); ?> </span>
                            <a href="<?php echo e(route('product.details',['id'=>$product->id])); ?>" class="btn btn-primary btn-sm">Details</a>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH I:\Laravel Project BITM\ecommerce-project\resources\views/category/details.blade.php ENDPATH**/ ?>