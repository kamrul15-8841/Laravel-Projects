<!Doctype html>
<html>

<head>
    <meta charset="UTF-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0,minimum-"/>

    <title> OTMS <?php echo $__env->yieldContent('title'); ?></title>

    <link rel="stylesheet" href="<?php echo e(asset('/')); ?>website/css/all.css"/>
    <link rel="stylesheet" href="<?php echo e(asset('/')); ?>website/css/bootstrap.css"/>
    <link rel="stylesheet" href="<?php echo e(asset('/')); ?>website/css/style.css"/>
</head>

<body>
    <nav class="navbar navbar-expand-md navbar-dark bg-dark">
        <div class="container">
            <a href="" class="navbar-brand">OTMS</a>
            <ul class="navbar-nav">
                <li><a href="<?php echo e(route('home')); ?>" class="nav-link">Home</a></li>
                <li><a href="" class="nav-link">About</a></li>
                <li class="dropdown">
                    <a href="" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">Training category</a>
                    <ul class="dropdown-menu">
                        <li><a href="" class="dropdown-item">Web Design</a></li>
                        <li><a href="" class="dropdown-item">Web Development</a></li>
                    </ul>
                </li>
                <li><a href="" class="nav-link">All Training</a></li>
                <li><a href="" class="nav-link">Contact</a></li>
                <li><a href="" class="nav-link">Login/Registration</a></li>
            </ul>
        </div>
    </nav>

    <?php echo $__env->yieldContent('body'); ?>

    <footer class="py-5 bg-dark">
        <div class="container">
            <div class="row">
                <div class="col-md-3">
                    <div class="card card-body h-100">
                        <h1>OTMS</h1>
                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Atque
                            consequuntur dolor ducimus impedit incidunt laboriosam laborum libero
                            maxime necessitatibus non nostrum numquam odio,
                            officia quaerat quam reiciendis tenetur ut velit.</p>
                    </div>
                </div>
                <div class="col-md-5">
                    <div class="card card-body h-100">
                        <h3>Populer Training</h3>
                        <ul class="navbar-nav">
                            <li><a href="" class="nav-link">PHP With Laravel Framework</a></li>
                            <li><a href="" class="nav-link">Mobile App Development</a></li>
                            <li><a href="" class="nav-link">Responsive Web Design</a></li>
                            <li><a href="" class="nav-link">Professional Digital Marketing</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card card-body h-100">
                        <h1>Contact With Us</h1>
                        <address>
                            House No - 420, Road No - 520, Dhanmondi, Dhaka-1200
                        </address>
                        <h3>Follow Us</h3>
                        <ul class="nav">
                            <li><a href="nav-link"><i class="fa-brands fa-square-facebook"></i></a></li>
                            <li><a href="nav-link"><i class="fa-brands fa-instagram"></i></a></li>
                            <li><a href="nav-link"><i class="fa-brands fa-square-twitter"></i></a></li>
                            <li><a href="nav-link"><i class="fa-brands fa-linkedin"></i></a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </footer>

<script src="<?php echo e(asset('/')); ?>website/js/jquery-3.6.1.js"></script>
<script src="<?php echo e(asset('/')); ?>website/js/bootstrap.bundle.js"></script>
</body>
</html>
<?php /**PATH F:\php_with_laravel_(Sohan)_Batch-13\OTMS-project\resources\views/master.blade.php ENDPATH**/ ?>