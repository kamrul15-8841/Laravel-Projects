@extends('master')

@section('body')
    <section class="py-5">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h1 class="text-center">All Brand</h1>
                </div>
            </div>
        </div>
    </section>
@endsection
