<!Doctype html>
<html>

<head>
    <meta charset="UTF-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0,minimum-"/>

    <title><?php echo $__env->yieldContent('bitm'); ?></title>

    <link rel="stylesheet" href="<?php echo e(asset('/')); ?>css/all.css"/>
    <link rel="stylesheet" href="<?php echo e(asset('/')); ?>css/bootstrap.css"/>
    <link rel="stylesheet" href="<?php echo e(asset('/')); ?>css/style.css"/>
</head>
<body>
<nav class="navbar navbar-expand-md navbar-light bg-light">
    <div class="container">
        <a href="" class="navbar-brand text-uppercase">My Blog</a>
        <ul class="navbar-nav">
            <li><a href="<?php echo e(route('home')); ?>" class="nav-link">Home</a></li>
            <li class="dropdown">
                <a href="" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">Category</a>
                <ul class="dropdown-menu">
                    <li><a href="<?php echo e(route('category.index')); ?>" class="dropdown-item">Add Category</a></li>
                    <li><a href="<?php echo e(route('category.manage')); ?>" class="dropdown-item">Manage Category</a></li>
                </ul>
            </li>
            <li class="dropdown">
                <a href="" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">Blog</a>
                <ul class="dropdown-menu">
                    <li><a href="<?php echo e(route('blog.create')); ?>" class="dropdown-item">Add Blog</a></li>
                    <li><a href="<?php echo e(route('blog.index')); ?>" class="dropdown-item">Manage Blog</a></li>
                </ul>
            </li>
        </ul>
    </div>
</nav>

<?php echo $__env->yieldContent('body'); ?>

<script src="<?php echo e(asset('/')); ?>js/jquery-3.6.1.js"></script>
<script src="<?php echo e(asset('/')); ?>js/bootstrap.bundle.js"></script>
</body>
</html>
<?php /**PATH F:\php_with_laravel_(Sohan)_Batch-13\My-Blog\resources\views/master.blade.php ENDPATH**/ ?>