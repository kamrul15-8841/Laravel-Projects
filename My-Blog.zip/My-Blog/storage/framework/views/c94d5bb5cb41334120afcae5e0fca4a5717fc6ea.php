<?php $__env->startSection('body'); ?>
    <section class="py-5">
        <div class="container">
            <div class="row">
                <div class="col-md-8 mx-auto">
                    <div class="card">
                        <div class="card-header"><h4>All Blogs Information</h4></div>
                        <div class="card-body">
                            <h3 class="text-success text-center"><?php echo e(Session::get('message')); ?></h3>
                            <h3 class="text-danger text-center"><?php echo e(Session::get('message_delete')); ?></h3>
                            <table class="table table-bordered ">
                                <tr>
                                    <th>Blog Id</th>
                                    <td><?php echo e($blog->id); ?></td>
                                </tr>

                                <tr>
                                    <th>Blog Title</th>
                                    <td><?php echo e($blog->title); ?></td>
                                </tr>

                                <tr>
                                    <th>Blog Category</th>
                                    <td><?php echo e($blog->category->name); ?></td>
                                </tr>

                                <tr>
                                    <th>Blog short Description</th>
                                    <td><?php echo e($blog->short_description); ?></td>
                                </tr>
                                <tr>
                                    <th>Blog long Description</th>
                                    <td><?php echo e($blog->long_description); ?></td>
                                </tr>
                                <tr>
                                    <th>Blog Image</th>
                                    <td><img src="<?php echo e(asset($blog->image)); ?>" alt="" height="50" width="70"></td>
                                </tr>
                                <tr>
                                    <th>Blog Publication Status</th>
                                    <td><?php echo e($blog->status == 1? 'Published': 'Unpublished'); ?></td>
                                </tr>
                                <tr>
                                    <th>Total Hit Count</th>
                                    <td><?php echo e($blog->hit_count); ?></td>
                                </tr>

                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\php_with_laravel_(Sohan)_Batch-13\My-Blog\resources\views/blog/detail.blade.php ENDPATH**/ ?>