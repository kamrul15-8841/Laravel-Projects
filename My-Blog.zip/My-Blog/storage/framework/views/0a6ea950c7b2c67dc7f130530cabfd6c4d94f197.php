<?php $__env->startSection('body'); ?>
    <section class="py-5">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">Create Category</div>
                        <div class="card-body">



                            <table class="table table-bordered table-hover">
                                <thead>
                                <tr>
                                    <th>SL NO</th>
                                    <th>Name</th>
                                    <th>Description</th>
                                    <th>Image</th>
                                    <th>Action</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($category->name); ?></td>
                                        <td><?php echo e($category->description); ?></td>
                                        <td><img src="<?php echo e(asset($category->image)); ?>" alt="image" height="50" width="70"></td>
                                        <td>
                                            <a href="<?php echo e(route('category.edit',['id'=>$category->id])); ?>" class="btn btn-outline-success btn-sm">Edit</a>
                                            <a href="<?php echo e(route('category.delete',['id'=>$category->id])); ?>" class="btn btn-outline-danger btn-sm" onclick="return confirm('Are you sure to delete this')">Delete</a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Sohan\development\php_with_laravel\Laravel\My-Blog\resources\views/category/manage.blade.php ENDPATH**/ ?>