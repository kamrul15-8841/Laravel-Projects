@extends('master')


@section('body')
    <section class="py-5">
        <div class="container">
            <div class="row">
                <div class="col-md-8 mx-auto">
                    <div class="card">
                        <div class="card-header"><h4>All Blogs Information</h4></div>
                        <div class="card-body">
                            <h3 class="text-success text-center">{{ Session::get('message') }}</h3>
                            <h3 class="text-danger text-center">{{ Session::get('message_delete') }}</h3>
                            <table class="table table-bordered ">
                                <tr>
                                    <th>Blog Id</th>
                                    <td>{{$blog->id}}</td>
                                </tr>

                                <tr>
                                    <th>Blog Title</th>
                                    <td>{{$blog->title}}</td>
                                </tr>

                                <tr>
                                    <th>Blog Category</th>
                                    <td>{{$blog->category->name}}</td>
                                </tr>

                                <tr>
                                    <th>Blog short Description</th>
                                    <td>{{$blog->short_description}}</td>
                                </tr>
                                <tr>
                                    <th>Blog long Description</th>
                                    <td>{{$blog->long_description}}</td>
                                </tr>
                                <tr>
                                    <th>Blog Image</th>
                                    <td><img src="{{asset($blog->image)}}" alt="" height="50" width="70"></td>
                                </tr>
                                <tr>
                                    <th>Blog Publication Status</th>
                                    <td>{{$blog->status == 1? 'Published': 'Unpublished'}}</td>
                                </tr>
                                <tr>
                                    <th>Total Hit Count</th>
                                    <td>{{$blog->hit_count}}</td>
                                </tr>

                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
@endsection


