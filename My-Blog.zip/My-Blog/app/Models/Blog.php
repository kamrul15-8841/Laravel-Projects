<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Blade;

class Blog extends Model
{
    use HasFactory;

    private static $blog, $image, $imageName, $directory, $imageUrl, $imageExtension;

    private static function getImageUrl($request)
    {
//        self::$image = $request->file('image');
//        self::$imageName = self::$image->getClientOriginalName();
//        self::$directory = 'blog-images/';
//        self::$image->move(self::$directory, self::$imageName);
//        return self::$directory.self::$imageName;

        self::$image = $request->file('image');
//        self::$imageName = self::$image->getClientOriginalName();
        self::$imageExtension = self::$image ->getClientOriginalExtension();
        self::$imageName = time().' '.self::$imageExtension;
        self::$directory = 'blog-images/';
        self::$image->move(self::$directory, self::$imageName);
        return self::$directory.self::$imageName;
    }

    public static function newBlog($request)
    {
        self::saveBasicInfo(new Blog(), $request, self::getImageUrl($request));
    }

    public function category()
    {
        return $this->belongsTo(Category::class);//one to one relationship er khetre
    }

    public static function updateBlog($request, $id)
    {
        self::$blog = Blog::find($id);
        if ($request->file('image'))
        {
            if (file_exists(self::$blog->image))
            {
                unlink(self::$blog->image);
            }
            self::$imageUrl = self::getImageUrl($request);
        }
        else
        {
            self::$imageUrl = self::$blog->image;
        }

        self::saveBasicInfo(self::$blog, $request, self::getImageUrl());

    }

    public static function deleteBlog($id)
    {
        self::$blog = Blog::find($id);
        if (file_exists(self::$blog->image))
        {
            unlink(self::$blog->image);
        }
        self::$blog->delete();
    }

    public static function saveBasicInfo($blog, $request, $imageUrl)
    {
        $blog->category_id        = $request->category_id;
        $blog->title              = $request->title;
        $blog->short_description  = $request->short_description;
        $blog->long_description   = $request->long_description;
        $blog->image              = $imageUrl;
        $blog->save();
    }
}
