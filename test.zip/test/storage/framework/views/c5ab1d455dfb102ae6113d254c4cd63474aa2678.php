<?php $__env->startSection('title'); ?>
    Create User
<?php $__env->stopSection(); ?>
<?php $__env->startSection('body'); ?>
    <div class="row py-3">
        <div class="col-md-8 mx-auto">
            <div class="card">
                <div class="card-header">
                    <h3 class="float-start">Add User</h3>
                    <a href="<?php echo e(route('users.index')); ?>" class="btn btn-info float-end">Manage</a>
                </div>
                <div class="card-body">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <span class="text-danger text-center"><?php echo e($error); ?></span>
                        <br>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                    <h3 class="text-center text-info"><?php echo e(Session::has('message') ? Session::get('message') : ''); ?></h3>
                    <form method="POST" action="<?php echo e(route('users.store')); ?>" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>

                        <div class="row mt-3">
                            <label for="" class="col-md-4">First Name</label>
                            <div class="col-md-8">
                                <input type="text" name="first_name" class="form-control">


                            </div>
                        </div>

                        <div class="row mt-3">
                            <label for="" class="col-md-4">Last Name</label>
                            <div class="col-md-8">
                                <input type="text" name="last_name" class="form-control">
                            </div>
                        </div>

                        <div class="row mt-3">
                            <label for="" class="col-md-4">Email</label>
                            <div class="col-md-8">
                                <input type="email" name="email" class="form-control">
                            </div>
                        </div>

                        <div class="row mt-3">
                            <label for="" class="col-md-4">Password</label>
                            <div class="col-md-8">
                                <input type="password" name="password" class="form-control">
                            </div>
                        </div>

                        <div class="row mt-3">
                            <label for="" class="col-md-4"></label>
                            <div class="col-md-8">
                                <input type="submit"  class="btn btn-outline-info" value="Create User">
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>






<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel-Projects\test\resources\views/user/create.blade.php ENDPATH**/ ?>