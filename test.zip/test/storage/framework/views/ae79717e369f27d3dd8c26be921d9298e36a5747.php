<?php $__env->startSection('title'); ?>
    Manage User
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
    <div class="row">
        <div class="col-md-12 mx-auto">
            <div class="card">
                <div class="card-header">
                    <h3 class="float-start">Manage User </h3>
                    <span>
                        <a href="<?php echo e(route('users.create')); ?>" class="btn btn-info float-end">Create</a>
                    </span>
                </div>
                <div class="card-body table-responsive">
                <div class="card-body">
                    <h3 class="text-center text-info"><?php echo e(Session::has('message') ? Session::get('message') : ''); ?></h3>
                    <table class="table table-hover table-bordered " id="basic-datatable">
                    <table class="table table-hover table-bordered " id="courseTable">
                        <table id="courseTable" class="table table-hover table-striped w-100 nowrap">
                        <thead>
                        <tr>
                            <th>SI NO</th>
                            <th>First Name</th>
                            <th>Last Name</th>
                            <th>Email</th>
                            <th>Action</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($user->first_name); ?></td>
                                <td><?php echo e($user->last_name); ?></td>
                                <td><?php echo e($user->email); ?></td>
                                <td>






                                    <a href="<?php echo e(route('users.edit', $user->id)); ?>" class="btn btn-md btn-warning" title="Edit Course" style="display: inline-block">

                                        Edit
                                    </a>

                                    <form action="<?php echo e(route('users.destroy', $user->id)); ?>" method="post" style="display: inline-block">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('delete'); ?>
                                        <button type="submit" class="btn btn-sm btn-danger "  onclick="return confirm('Are you sure you want to delete this');" title="Delete Course">

                                            Delete
                                        </button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>





<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel-Projects\test\resources\views/user/index.blade.php ENDPATH**/ ?>