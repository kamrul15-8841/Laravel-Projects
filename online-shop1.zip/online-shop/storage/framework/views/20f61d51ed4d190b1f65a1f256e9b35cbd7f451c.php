<div class="vertical-menu">

    <div data-simplebar class="h-100">

        <!--- Sidemenu -->
        <div id="sidebar-menu">
            <!-- Left Menu Start -->
            <ul class="metismenu list-unstyled" id="side-menu">
                <li class="menu-title">Menu</li>
                <li> <a href="<?php echo e(route('dashboard')); ?>"><span>Dashboards</span></a></li>

                <li class="dropdown">
                    <a href="javascript: void(0);" role="button" class="has-arrow waves-effect " data-bs-toggle="dropdown">
                        <i class="bx bx-layout"></i>
                        <span>Category</span>
                    </a>
                    <ul class="dropdown-menu" aria-expanded="false">
                        <li><a class="dropdown-item text-info h1 font-weight-bold" href="<?php echo e(route('categories.create')); ?>">Add Category</a></li>
                        <li><a class="dropdown-item text-info h1 font-weight-bold" href="<?php echo e(route('categories.index')); ?>">Manage Category</a></li>
                    </ul>
                </li>

                <li class="dropdown">
                    <a href="javascript: void(0);" role="button" class="has-arrow waves-effect " data-bs-toggle="dropdown">
                        <i class="bx bx-layout"></i>
                        <span>Brand</span>
                    </a>
                    <ul class="dropdown-menu" aria-expanded="false">
                        <li><a class="dropdown-item text-info h1 font-weight-bold" href="<?php echo e(route('brands.create')); ?>">Add Brand</a></li>
                        <li><a class="dropdown-item text-info h1 font-weight-bold" href="<?php echo e(route('brands.index')); ?>">Manage Brand</a></li>
                    </ul>
                </li>

                <li class="dropdown">
                    <a href="javascript: void(0);" role="button" class="has-arrow waves-effect " data-bs-toggle="dropdown">
                        <i class="bx bx-layout"></i>
                        <span>Product</span>
                    </a>
                    <ul class="dropdown-menu" aria-expanded="false">
                        <li><a class="dropdown-item text-info h1 font-weight-bold" href="<?php echo e(route('products.create')); ?>">Product</a></li>
                        <li><a class="dropdown-item text-info h1 font-weight-bold" href="<?php echo e(route('products.index')); ?>">Manage Product</a></li>
                    </ul>
                </li>












            </ul>
        </div>
        <!-- Sidebar -->
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\Laravel-Projects\online-shop\resources\views/admin/includes/left-sidebar.blade.php ENDPATH**/ ?>