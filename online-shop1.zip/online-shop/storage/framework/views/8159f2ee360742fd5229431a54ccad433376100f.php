<?php $__env->startSection('title'); ?>
    Create Category
<?php $__env->stopSection(); ?>
<?php $__env->startSection('body'); ?>
    <div class="row py-3">
        <div class="col-md-8 mx-auto">
            <div class="card">
                <div class="card-header">
                    <h3 class="float-start">Add Category</h3>
                    <a href="<?php echo e(route('categories.index')); ?>" class="btn btn-info float-end">Manage</a>
                </div>
                <div class="card-body">
                    
                    <h3 class="text-center text-info"><?php echo e(Session::has('message') ? Session::get('message') : ''); ?></h3>
                    <form method="POST" action="<?php echo e(route('categories.store')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="row mt-3">
                            <label for="" class="col-md-4">Category Name</label>
                            <div class="col-md-8">
                                <input type="text" name="name" class="form-control">
                            </div>
                        </div>
                        <div class="row mt-3">
                            <label for="" class="col-md-4">Status</label>
                            <div class="col-md-8">
                                <label><input type="radio" name="status" value="1" checked> Published</label>
                                <label><input type="radio" name="status" value="0"> Unpublished</label>
                            </div>
                        </div>
                        <div class="row mt-3">
                            <label for="" class="col-md-4"></label>
                            <div class="col-md-8">
                                <input type="submit"  class="btn btn-outline-info" value="Add Category">
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.dashboard.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel-Projects\online-shop\resources\views/admin/category/create.blade.php ENDPATH**/ ?>