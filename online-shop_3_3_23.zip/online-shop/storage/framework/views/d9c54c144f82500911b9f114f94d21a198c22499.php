<!-- Bootstrap Css -->
<link href="<?php echo e(asset('/')); ?>admin/css/bootstrap.min.css" id="bootstrap-style" rel="stylesheet" type="text/css" />
<!-- Icons Css -->
<link href="<?php echo e(asset('/')); ?>admin/css/icons.min.css" rel="stylesheet" type="text/css" />
<!-- App Css-->
<link href="<?php echo e(asset('/')); ?>admin/css/app.min.css" id="app-style" rel="stylesheet" type="text/css" />


<link href="<?php echo e(asset('/')); ?>assets/css/all.css" id="app-style" rel="stylesheet" type="text/css" />

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
<?php /**PATH C:\xampp\htdocs\Laravel-Projects\online-shop\resources\views/admin/includes/style.blade.php ENDPATH**/ ?>